package ca.mcgill.ecse211.lab4;

public interface LightHandler {
	public void processLightData(int data);
	public int readLightData();
}
